//
//  ViewController.swift
//  Quiz2
//
//  Created by Shawn Ng Y K on 19/3/18.
//  Copyright © 2018 SST. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var window: UIWindow?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title="Jokes Quiz"
        self.view.backgroundColor=UIColor.white
        
        setupViews()
    }
    
    @objc func btnGetStartedAction() {
        let v=QuizVC()
        self.navigationController?.pushViewController(v, animated: true)
    }
    
    func setupViews() {
        self.view.addSubview(lblTitle)
        lblTitle.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 200).isActive=true
        lblTitle.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive=true
        lblTitle.widthAnchor.constraint(equalToConstant: 300).isActive=true
        lblTitle.heightAnchor.constraint(equalToConstant: 80).isActive=true
        
        self.view.addSubview(btnGetStarted)
        btnGetStarted.topAnchor.constraint(equalTo: lblTitle.bottomAnchor, constant: 50).isActive=true
        btnGetStarted.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive=true
        btnGetStarted.widthAnchor.constraint(equalToConstant: 300).isActive=true
        btnGetStarted.heightAnchor.constraint(equalToConstant: 80).isActive=true
    }
    
    let lblTitle: UILabel = {
        let lbl=UILabel()
        lbl.text="Jokes On You"
        lbl.textColor=UIColor.green
        lbl.backgroundColor=UIColor.darkGray
        lbl.layer.cornerRadius=7
        lbl.layer.masksToBounds=true
        lbl.textAlignment = .center
        lbl.font = UIFont.systemFont(ofSize: 45)
        lbl.numberOfLines=2
        lbl.translatesAutoresizingMaskIntoConstraints=false
        return lbl
    }()
    
    let btnGetStarted: UIButton = {
        let btn=UIButton()
        btn.setTitle("Tap Here Get Started", for: .normal)
        btn.setTitleColor(UIColor.yellow, for: .normal)
        btn.backgroundColor=UIColor.darkGray
        btn.layer.cornerRadius=7
        btn.layer.masksToBounds=true
        btn.translatesAutoresizingMaskIntoConstraints=false
        btn.addTarget(self, action: #selector(btnGetStartedAction), for: .touchUpInside)
        return btn
    }()
}








